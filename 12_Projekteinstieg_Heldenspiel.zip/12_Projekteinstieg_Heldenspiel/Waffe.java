/**
  *
  * @version 1.0 vom 10.09.2015
  * @author  Thomas Kempe
  */

public class Waffe {
  
  // Anfang Attribute
  private int bonus;
  private String material;
  private int magie;
  // Ende Attribute
  
  public Waffe(int pBo, String pMat, int pMag) {
    this.material = pMat;
    this.magie = pMag;
    bonusBerechnen();
  }
  
  // Anfang Methoden
  public void bonusBerechnen() {
    int matBonus=1;
    if(material.equals("Eisen")){
      matBonus = 2;                              
    }
    if(material.equals("Silber")){
      matBonus = 3;
    }    
  } // end of if-else
  
  
  public int getBonus() {
    return bonus;
  }
  
  public void setBonus(int pBo) {
    this.bonus = bonus;
  }
  
  public String getMaterial() {
    return material;
  }
  
  public void setMaterial(String pMat) {
    this.material = pMat;
  }
  
  public int getMagie() {
    return magie;
  }
  
  public void setMagie(int pMag) {
    this.magie = pMag;
  }
  
  // Ende Methoden
} // end of Waffe
