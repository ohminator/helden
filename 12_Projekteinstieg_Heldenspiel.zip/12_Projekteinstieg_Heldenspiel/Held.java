/**
  *
  * @version 1.0 vom 10.09.2015
  * @author Thomas Kempe
  */

public class Held {
  
  // Anfang Attribute
  protected String name;
  protected int staerke;
  protected int angriffswert;
  protected int lebenspunkte;
  protected Waffe meineWaffe;
  // Ende Attribute
  
  public Held(String pNa, int pSt, int pLp, Waffe pWa) {
    this.name = pNa;
    this.staerke = pSt;
    this.lebenspunkte = pLp;
    this.meineWaffe = pWa;
    angriffswertBerechnen();
  }
  
  // Anfang Methoden
  
  public void kaempfen(){ 
    //--> wird hier ausgespart
  }
  
  /**
  *   Der Angriffswert wird über das Attribute staerke und den Bonus von meineWaffe ermittelt.
  *   @param kein Parameter
  */  
  
  public void angriffswertBerechnen() {
    angriffswert = staerke + meineWaffe.getBonus();
  }
  
  public String getName() {
    return name;
  }
  
  public void setName(String pNa) {
    this.name = pNa;
  }
  
  public int getStaerke() {
    return staerke;
  }
  
  public void setStaerke(int pSt) {
    this.staerke = pSt;
  }
  
  public int getAngriffswert() {
    return angriffswert;
  }
  
  public void setAngriffswert(int pAw) {
    this.angriffswert = pAw;
  }
  
  public int getLebenspunkte() {
    return lebenspunkte;
  }
  
  public void setLebenspunkte(int pLp) {
    this.lebenspunkte = pLp;
  }
  
  public Waffe getWaffe() {
    return meineWaffe;
  }
  
  public void setWaffe(Waffe meineWaffe) {
    this.meineWaffe = meineWaffe;
  }
  
  // Ende Methoden
} // end of Held
