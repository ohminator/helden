/**
  *
  * @version 1.0 vom 10.09.2015
  * @author Thomas Kempe
  */

public class Krieger extends Held {
  
  // Anfang Attribute
  private int ausdauer;
  // Ende Attribute
  
  public Krieger(String pNa, int pSt, int pLp, Waffe pWa, int pAu) {
    super(pNa,pSt,pLp,pWa);
    ausdauer = pAu;
  }
  
  // Anfang Methoden
  
  public void angriffswertBerechnen() {
    angriffswert = ausdauer*(staerke + meineWaffe.getBonus());
  }
  
  public int getAusdauer() {
    return ausdauer;
  }
  
  public void setAusdauer(int pAu) {
    this.ausdauer = pAu;
  }
  
  // Ende Methoden
} // end of Krieger
